// Isolated static design preview. No product API, user data, writes or model calls.
import {createServer} from 'node:http';
import {readFile} from 'node:fs/promises';
import {resolve,extname,dirname} from 'node:path';
import {fileURLToPath} from 'node:url';
const here=dirname(fileURLToPath(import.meta.url)), repo=resolve(here,'../../..');
const mime={'.html':'text/html; charset=utf-8','.css':'text/css','.js':'text/javascript','.png':'image/png','.svg':'image/svg+xml','.ttf':'font/ttf','.woff2':'font/woff2','.woff':'font/woff'};
createServer(async(req,res)=>{try{
const p=decodeURIComponent(new URL(req.url,'http://127.0.0.1').pathname);
let root=here,rel=p==='/'?'index.html':p.slice(1);
if(p.startsWith('/vendor/katex/')){root=resolve(repo,'frontend/node_modules/katex/dist');rel=p.slice(14);}
if(p.startsWith('/fonts/')){root=resolve(repo,'frontend/src/assets/fonts');rel=p.slice(7);}
if(p==='/brand.svg'){root=resolve(repo,'frontend/public/brand');rel='texa-mark.svg';}
const file=resolve(root,rel);if(!file.startsWith(root+'/'))throw Error('invalid path');
res.setHeader('Content-Type',mime[extname(file)]||'application/octet-stream');res.setHeader('Cache-Control','no-store');res.end(await readFile(file));
}catch{res.writeHead(404);res.end('Not found');}}).listen(5197,'127.0.0.1',()=>console.log('Texa isolated design preview: http://127.0.0.1:5197/'));
