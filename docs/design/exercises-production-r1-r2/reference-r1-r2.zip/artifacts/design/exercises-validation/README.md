# Texa isolated visual prototype — R2

设计验证日期：2026-10-15 至 2026-10-16。仅本地固定样例，不连接生产API，不上传文件内容，不调用模型，不写题库。

从仓库根目录运行：

```sh
node artifacts/design/exercises-validation/server.mjs
```

打开 http://127.0.0.1:5197/ 。服务仅监听127.0.0.1。需要现有 `frontend/node_modules/katex/dist` 以及仓库的 HarmonyOS 字体/品牌文件。不需要安装依赖。服务进程退出后可按上面命令重启；直接双击index.html无法解析绝对资源路径。

- `/`：设计方向与状态目录。
- `/gallery.html`：既有界面对照、双尺寸最终截图、补充状态。
- `?view=practice / empty / import / review`：四个核心场景。
- `?view=file / file-ready / processing / failure / edit / review-source / success / unknown / reload / restored / resume`：其他状态。
- `?view=bank-reading / bank-ai`：题库中的习题阅读与 AI 解题。
- `?view=exercise-reading / exercise-ai / exercise-generating / exercise-failed`：当前练习作答、AI 草稿、生成中、连接中断。
- `?view=mistake-reading / mistake-ai / mistake-failed`：错题阅读、AI 讲解、写入结果未知。
- `?view=direction-b / direction-b-import`：B方案结构草案。

可操作：题量/顺序选择、来源切换、样例解析→校对、候选选择与过滤、题干/答案/解析编辑、原文模式、返回来源与继续、确认与样例回执。候选修改只在内存。刷新会重置固定样例。页面导航为演示导航，不是生产路由。

教材/学科/章节筛选使用固定选项和固定数据，不证明真实范围联动；手动录入、PDF、回滚、批次核对、真实练习与单题会话仍未接入。合并/拆分是示意交互，正式实现必须复用candidateOperations，不复制原型算法。成功页数字为样例演示，不是实际数据库结果。

R2 增加可操作的问号提示、题目／解答切换、作答保留、AI草稿编辑／保存、错题写入前确认；全部是内存演示。不会调用模型、写入记录或提交自评。

本原型不是待复制的React实现，不使用真实Electron shell。导航占位按现有宽度232/208px模拟，仅为了验证剩余空间。正式实现仍须真实Electron截图复审。

正式交付文档：
- `docs/design/exercises-visual-validation/reading-and-copy-r2-2026-10-16.md`（当前增补）
- `docs/design/exercises-visual-validation/design-review-2026-10-16.md`
- `docs/design/exercises-visual-validation/sol-handoff-2026-10-16.md`

`screenshots/r2/` 是本轮截图（其中v1为阅读初稿）；根screenshots中的文件属于R1，`gallery-r1.html`保留上一轮画廊；before-* 是既有仓库参考。`archive-v1/`保存R1源码快照。`evidence-manifest.json`记录最终文件hash和视口。artifacts目录被Git忽略，需显式保留本地交付，不能假定自动随提交发布。
